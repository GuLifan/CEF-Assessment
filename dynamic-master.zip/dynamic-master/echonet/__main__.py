"""Entry point for command line."""

import echonet


if __name__ == '__main__':
    echonet.main()
