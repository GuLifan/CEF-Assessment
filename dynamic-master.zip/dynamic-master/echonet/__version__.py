"""Version number for Echonet package."""

__version__ = "1.0.0"
